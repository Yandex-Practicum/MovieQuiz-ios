import Foundation

protocol QuestionFactoryProtocol {
    func requestNextQuestion()
}
