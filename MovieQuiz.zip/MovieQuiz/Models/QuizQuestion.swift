//
// Model данных для вопросов
//

import Foundation

struct QuizQuestion {
    let image: Data
    let text: String
    let correctAnswer: Bool
}
