//
// ViewModel отдельного вопроса
//

import UIKit

struct QuizStepViewModel {
    let image: Data
    let question: String
    let questionNumber: String
}
