//
// ViewModel результата квиза, нужна для алерта
//

import Foundation

struct QuizResultViewModel {
    let title: String
    let text: String
    let buttonText: String
}
